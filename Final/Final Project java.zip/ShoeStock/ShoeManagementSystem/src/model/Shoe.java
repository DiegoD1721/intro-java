package model;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.File;

// General Shoe class
public abstract class Shoe extends InventoryItem {
    protected int size;
    protected String shoeType;

    public Shoe(String style, double price, int size, String shoeType) {
        super(style, price);
        this.size = size;
        this.shoeType = shoeType;
    }

    public int getSize() {
        return size;
    }

public void addShoe() {
        try (FileWriter fw = new FileWriter("shoes.txt", true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            } catch (IOException e) {
            e.printStackTrace();
        }
    }
public static void createAndWriteShoe(String style, double price, int size, String shoeType) {
	System.out.print(style);
    Shoe shoe;
    switch (shoeType.toLowerCase()) {
        case "sports":
            shoe = new SportsShoe(style, price, size, shoeType);
            break;
        case "formal":
            shoe = new FormalShoe(style, price, size, shoeType);
            break;
        default:
            throw new IllegalArgumentException("Invalid shoe type");
    }
    writeShoeToFile(shoe);
}
private static void writeShoeToFile(Shoe shoe) {
    // Specify the file name
    String fileName = "shoes.txt";

    try {
        // Create a File object
        File file = new File(fileName);

        // Check if the file exists; if not, create it
        if (!file.exists()) {
            file.createNewFile();
        }

        // Use a BufferedWriter to write data to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(shoe.toString() + System.lineSeparator());
            System.out.print("Data has been written to the file: " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    } catch (IOException e) {
        e.printStackTrace();
    }



}


    // Inside Shoe class

public String toStringDetails() {
	// TODO Auto-generated method stub
	return null;
}

}
