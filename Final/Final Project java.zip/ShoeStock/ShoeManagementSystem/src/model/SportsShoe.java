package model;

public class SportsShoe extends Shoe {

    public SportsShoe(String style, double price, int size, String type) {
        super(style, price, size, type);
    }

    @Override
    public String toString() {
        return "Sports Shoe Details: " +
                "Style: " + getStyle() +
                ", Size: " + getSize() +
                ", Price: " + getPrice() +
                ", Type: " + getType() +
                '}';
    }

    // Getter methods for the fields
    public String getStyle() {
        return style;
    }

    public double getPrice() {
        return price;
    }

    public int getSize() {
        return size;
    }

    public String getType() {
        return shoeType;
    }
}
