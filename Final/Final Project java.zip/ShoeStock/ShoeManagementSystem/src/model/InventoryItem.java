package model;
//Abstract class representing an item in inventory
abstract class InventoryItem {
 protected String style;
 protected double price;

 public InventoryItem(String style, double price) {
     this.style = style;
     this.price = price;
 }
public abstract void addShoe();
}