package controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BuyShoeController {

    @FXML
    private TableView<List<String>> showTableView;

    private List<List<String>> shoes;

    @FXML
    public void initialize() {
        // Set up the columns
        TableColumn<List<String>, String> styleColumn = new TableColumn<>("Style");
        TableColumn<List<String>, String> sizeColumn = new TableColumn<>("Size");
        TableColumn<List<String>, String> priceColumn = new TableColumn<>("Price");
        TableColumn<List<String>, String> typeColumn = new TableColumn<>("Type");

        styleColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(0)));
        sizeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(1)));
        priceColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(2)));
        typeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().get(3)));

        showTableView.getColumns().addAll(styleColumn, sizeColumn, priceColumn, typeColumn);
        showTableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        showTableView.setPlaceholder(createPlaceholder("No data available"));

        // Populate the table with data from the file
        shoes = readShoesFromFile("shoes.txt");
        System.out.println(shoes);
        showTableView.getItems().addAll(shoes);

        // Add event handler for row selection
        showTableView.setOnMouseClicked(event -> {
            if (event.getClickCount() == 1) {
                handleRowClick();
            }
        });
    }

    private void handleRowClick() {
        List<String> selectedShoe = showTableView.getSelectionModel().getSelectedItem();
        if (selectedShoe != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Dialog");
            alert.setHeaderText("Buy Shoe Confirmation");
            alert.setContentText("Do you want to buy this shoe?\n" +
                    "Style: " + selectedShoe.get(0) +
                    "\nSize: " + selectedShoe.get(1) +
                    "\nPrice: " + selectedShoe.get(2) +
                    "\nType: " + selectedShoe.get(3));

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                // User clicked OK
                showBuySuccessAlert();
            }
        }
    }

    private void showBuySuccessAlert() {
        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
        successAlert.setTitle("Success");
        successAlert.setHeaderText(null);
        successAlert.setContentText("Shoe bought successfully!");
        successAlert.showAndWait();
    }

    private List<List<String>> readShoesFromFile(String fileName) {
        List<List<String>> shoes = new ArrayList<>();
        System.out.println(shoes);
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    List<String> shoe = parseShoeFromString(line);
                    if (shoe != null) {
                        shoes.add(shoe);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return shoes;
    }

    private List<String> parseShoeFromString(String shoeString) {
        List<String> components = new ArrayList<>();
        try {
            // Extracting values from the shoeString using regex
            Pattern pattern = Pattern.compile(": (.*?)(,|$)");
            Matcher matcher = pattern.matcher(shoeString);

            while (matcher.find()) {
                components.add(matcher.group(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return components;
    }

    private AnchorPane createPlaceholder(String message) {
        AnchorPane placeholder = new AnchorPane();
        javafx.scene.text.Text text = new javafx.scene.text.Text(message);
        text.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        placeholder.getChildren().add(text);
        AnchorPane.setTopAnchor(text, 10.0);
        AnchorPane.setBottomAnchor(text, 10.0);
        AnchorPane.setLeftAnchor(text, 10.0);
        AnchorPane.setRightAnchor(text, 10.0);
        return placeholder;
    }
}
