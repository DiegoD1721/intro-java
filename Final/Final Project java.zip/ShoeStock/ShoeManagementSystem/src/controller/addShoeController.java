package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import model.*;

public class addShoeController {

    @FXML
    private TextField styleTextField;

    @FXML
    private TextField sizeTextField;

    @FXML
    private TextField priceTextField;

    @FXML
    private ComboBox<String> typeComboBox;

    @FXML
    public void initialize() {
        ObservableList<String> shoeTypes = FXCollections.observableArrayList("Formal", "Sports");
        typeComboBox.setItems(shoeTypes);
    }

    @FXML
    private void handleAddShoeButtonAction(ActionEvent event) {
        System.out.print("1");
        
        // Validate input
        String style = styleTextField.getText();
        String sizeStr = sizeTextField.getText();
        String priceStr = priceTextField.getText();
        String selectedShoeType = typeComboBox.getValue();
        
        if (style.isEmpty() || sizeStr.isEmpty() || priceStr.isEmpty() || selectedShoeType == null) {
            showAlert("Please fill in all fields.", AlertType.ERROR);
            return; // Exit the method if any field is empty or type is not selected
        }
        
        try {
            int size = Integer.parseInt(sizeStr); // Size is typically an integer
            double price = Double.parseDouble(priceStr); // Price should be a double

            if (size <= 0 || price <= 0) {
                showAlert("Invalid size or price. Size and price must be positive numbers.", AlertType.ERROR);
                return; // Exit the method if size or price is not valid
            }

            Shoe.createAndWriteShoe(style, price, size, selectedShoeType);

            // Clear the text fields
            styleTextField.clear();
            sizeTextField.clear();
            priceTextField.clear();
            typeComboBox.getSelectionModel().clearSelection();
        } catch (NumberFormatException e) {
            showAlert("Invalid input format. Please enter valid numbers for size and price.", AlertType.ERROR);
        }
    }

    private void showAlert(String message, AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle("Input Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


}
