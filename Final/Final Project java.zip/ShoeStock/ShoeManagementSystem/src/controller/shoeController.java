package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class shoeController  {

    @FXML
    protected void handleAddShoeButtonAction() {
        openNewWindow("/view/add_shoe.fxml", "Add Shoe");
    }

    @FXML
    protected void handleViewAllShoesButtonAction() {
        openNewWindow("/View/AllShoesScreen.fxml", "Show Shoes");
    }
    @FXML
    protected void showShoeDetails() {
        openNewWindow("/view/shoeDetails.fxml", "Shoes Details");
    }
    @FXML
    protected void contactUs() {
        openNewWindow("/view/contactUs.fxml", "contact us");
    }
    @FXML
    protected void buy() {
        openNewWindow("/view/buyshoe.fxml","buy shoe");
    }
    private void openNewWindow(String fxmlFile, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the exception (show an error dialog or a message)
        }
    }



}
